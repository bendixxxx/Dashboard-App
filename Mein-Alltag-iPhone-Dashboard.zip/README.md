# Mein Alltag – iPhone Dashboard (Version 1)

Eine installierbare Web-App (PWA) für iPhone mit Aufgaben, Terminen und Projekten.

## Installation auf dem iPhone

1. Erstelle ein GitHub-Repository und lade die Dateien dieses Ordners in das Hauptverzeichnis hoch.
2. Öffne im Repository **Settings → Pages**. Wähle **Deploy from a branch**, Branch **main**, Ordner **/(root)** und speichere.
3. Öffne die dort angezeigte HTTPS-Adresse in **Safari auf dem iPhone**.
4. Wähle **Teilen → Zum Home-Bildschirm** (je nach iOS-Version im Teilen-Menü oder über „Mehr“). Aktiviere, falls angeboten, **Als Web-App öffnen**.
5. Tippe auf **Hinzufügen**. Die App erscheint als Icon auf dem Home-Bildschirm.

Hinweis: GitHub Pages veröffentlicht die Website öffentlich, auch wenn das Repository privat ist. In dieser Version liegen deine Aufgaben nur lokal im Browser-Speicher des iPhones und werden nicht an GitHub gesendet. Keine sensiblen Daten verwenden, solange Datenschutz und Synchronisierung nicht weiter ausgebaut wurden.

## Aktueller Funktionsumfang
- Aufgaben hinzufügen, bearbeiten, abhaken, löschen
- Termine hinzufügen, bearbeiten, löschen
- Projekte erstellen und Aufgaben zuordnen
- Tagesübersicht
- ChatGPT öffnen (noch **keine** direkte Datenbankanbindung)
- Offline-Nutzung nach erstem Laden (Service Worker)

## Grenzen von Version 1
- Keine Synchronisierung zwischen Geräten
- Keine Apple-Kalender-Anbindung
- Kein eingebetteter ChatGPT-Assistent
- Keine Datensicherung: Safari-Website-Daten löschen kann die gespeicherten Aufgaben löschen.

## Weiterentwicklung
SwiftUI-App mit CloudKit oder PWA mit authentifiziertem Cloud-Backend; danach sichere OpenAI-API-Anbindung.
